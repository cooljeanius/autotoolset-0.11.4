char F2C_version[] = "19971204";
char xxxvers[] = "\n@(#) FORTRAN 77 to C Translator, VERSION 19971204\n";
